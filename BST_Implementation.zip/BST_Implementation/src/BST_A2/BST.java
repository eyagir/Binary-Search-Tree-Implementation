package BST_A2;


public class BST implements BST_Interface {
	public BST_Node origin;
	public BST_Node root;
	int size;
	  
	public BST(){ size=0; root=null; }
	  
	  @Override
	  //used for testing
    public BST_Node getRoot(){ return root; }
	  
	public boolean insert(String s) {
		if (root == null) {
			root = new BST_Node(s);
			size++;
			return true;
		}
		size++;
		return root.insertNode(s);
	}

	public boolean remove(String s) {
		if (root.getData().equals(s) && root.right == null && root.left == null) {
			root = null;
			size--;
			return true;
		}
		size--;
		return root.removeNode(s);
	}

	public String findMin() {
		return root.findMin().getData();
	}

	public String findMax() {
		return root.findMax().getData();
	}

	public boolean empty() {
		if (root == null) {
			return true;
		} else {
			return false;
		}
	}

	public boolean contains(String s) {
		return root.containsNode(s);
	}

	public int size() {
		return size;
		
	}
	
	public int height() {
		if (root == null) {
			return 0;
		}
		return root.getHeight();
	}
	
	

}
