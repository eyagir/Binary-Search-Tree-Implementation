package BST_A2;

public class BST_Node {
  String data;
  BST_Node left;
  BST_Node right;
  BST_Node parent;
  
  BST_Node(String data){ this.data=data; }

  // --- used for testing  ----------------------------------------------
  //
  // leave these 3 methods in, as is

  public String getData(){ return data; }
  public BST_Node getLeft(){ return left; }
  public BST_Node getRight(){ return right; }
  public BST_Node getParent() { return parent; }

 
  
  public boolean containsNode(String s){ 
  		
	    if(this.getData().equals(s)) {
	    	//found
  			return true;
  		} else if(this.getData().compareTo(s) > 0) {
  			//must be on left side of tree or false
  			if (this.getLeft() == null) {
  				return false;
  			}
  			return this.getLeft().containsNode(s);
  		} else {
  			//must be on the right side of tree or false
  			if (this.getRight() == null) {
  				return false; 
  			}
  			return this.getRight().containsNode(s);
  		}
  }
  public boolean insertNode(String s){ 
	  if (this.getData().equals(s)) {
		  //prevent duplicate value
		  return false; 
	  } else if(this.getData().compareTo(s) > 0) {
			//must go on left side of tree or false
			if (this.getLeft() == null) {
				this.left = new BST_Node(s);
				this.left.parent = this;
				return true;
			} else {
				return this.getLeft().insertNode(s);
			}
		} else {
			//must go on the right side of tree or false
			if (this.getRight() == null) {
				this.right = new BST_Node(s);
				this.right.parent = this;
				return true;
			} else {
				return this.getRight().insertNode(s);
			}
		}
  }
  public boolean removeNode(String s){ 
	  BST_Node remov = this.containsNodeReturn(s);
	  if (remov == null) {
		  return false;
	  }
	  if (this.getData().equals(s)) {
		  BST_Node n = this.right.findMin();
		  this.data = n.getData();
		  if(n.parent.getLeft() == n) {
			  n.parent.left = null;
		  } else {
			  n.parent.right = null;
		  }
		  n.parent = null;
		  return true;
	  }
	  BST_Node node = remov.parent;
	  if (node == null) {
		  BST_Node holder = remov.findMin();
		  remov.data = holder.data;
		  if (holder.parent != null) {
		  if(holder.parent.getLeft() == holder) {
			  holder.parent.left = null;
		  } else {
			  holder.parent = null;
		  }
		  }
		  holder.parent = null;
	  } else if (remov.getLeft() == null && remov.getRight() == null) {
		  if(node.getLeft() == remov) {
			  node.left = null;
		  } else {
			  node.right = null;
		  }
		  remov.parent = null;
		  return true;
	  } else if (remov.getRight() == null) {
		  remov.getLeft().parent = node;
		  if(node.getLeft() == remov) {
			  node.left = remov.getLeft();
		  } else {
			  node.right = remov.getLeft();
		  }
		  remov.parent = null;
		  remov.left = null;
		  return true;
	  } else if (remov.getLeft() == null) {
		  remov.getRight().parent = node;
		  if(node.getLeft() == remov) {
			  node.left = remov.getRight();
		  } else {
			  node.right = remov.getRight();
		  }
		  remov.parent = null;
		  remov.right = null;
		  return true;
	  } else {
		 BST_Node temp = remov.right.findMin();
		 remov.data = temp.data;
		 if(temp.parent.getLeft() == temp) {
			  temp.parent.left = null;
		  } else {
			  temp.parent.right = null;
		  }
//		 if(node.getLeft() == remov) {
//			  node.left = temp;
//		  } else {
//			  node.right = temp;
//		  }
//		 temp.right = remov.getRight();
//		 temp.left = remov.getLeft();
//		 temp.parent = remov.parent;
		 temp.parent = null;
		 temp.right = null;
		 temp.left = null;
		 return true;
	  }
	  return true;
  }
  public BST_Node findMin(){
	  if (this.left == null)
		  return this;
	  else
		  return this.left.findMin();
  }
  public BST_Node findMax(){ 
	  if (this.right == null)
		  return this;
	  else
		  return this.right.findMax();
 }
  public int getHeight(){ 
	  BST_Node node = this;
	  int leftMax = 0;
	  int rightMax = 0;
	  while(node != null) {
		  node = node.left;
		  leftMax++;
	  }
	  node = this;
	  while(node != null) {
		  node = node.right;
		  rightMax++;
	  }
	  if (rightMax >= leftMax) {
		  return rightMax;
	  } else {
		  return leftMax;
	  }
  }
  
  // extra method to return the node that contains a certain string
  public BST_Node containsNodeReturn(String s){ 
		
	    if(this.getData().equals(s)) {
	    	//found
			return this;
		} else if(this.getData().compareTo(s) > 0) {
			//must be on left side of tree or false
			if (this.getLeft() == null) {
				return null;
			}
			return this.getLeft().containsNodeReturn(s);
		} else {
			//must be on the right side of tree or false
			if (this.getRight() == null) {
				return null; 
			}
			return this.getRight().containsNodeReturn(s);
		}
}


  
  public String toString(){
    return "Data: "+this.data+", Left: "+((this.left!=null)?left.data:"null")
            +",Right: "+((this.right!=null)?right.data:"null");
  }
}